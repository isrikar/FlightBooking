'use strict';
 
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Card, Suggestion} = require('dialogflow-fulfillment');
let date = require('date-and-time');

process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements
 
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
 
var totalflights = '{"inst" : [{"From": "Chennai","To": "Singapore","Airlines": "Singapore Airlines","Seats": 25,"FlightNo": "SA1234","Date":"22/08/2019","Ref_no": "1290,432,454545,667567,32312","Connection": "False","Price": "Rs 22,000"},{"From": "Chennai","To": "Singapore","Airlines": "China Airlines","Seats": 25,"FlightNo": "CA1434","Date":"22/08/2019","Ref_no": "129032,43247,84432,235674,976543","Connection": "False","Price": "Rs 19,000"},{"From": "Chennai","To": "Singapore","Airlines": "ABC Airlines","Seats": 25,"FlightNo": "AA234","Date":"22/08/2019","Ref_no": "129023,45643,23423412,65757","Connection": "True","Price": "Rs 13,000"},{"From": "Chennai","To": "Singapore","Airlines": "XYZ Airlines","Seats": 25,"FlightNo": "YZ1234","Date":"22/08/2019","Ref_no": "1290231,53523,4324656,78867,2426475,78675","Connection": "True","Price": "Rs 12,000"},{"From": "Tirupati","To": "Chennai","Airlines": "Balaji Airlines","Seats": 27,"FlightNo": "BA010","Date": "23/08/2019","Ref_no": "1234","Connection": "True","Price": "Rs 2,000"},{"From": "Tirupati","To": "Chennai","Airlines": "iOPEX Airlines","Seats": 27,"FlightNo": "iOPEX010","Date": "23/08/2019","Ref_no": "12347665,24424,6876,864234,64242644,424646,75673563,8698657,2424,23423,442","Connection": "False","Price": "Rs 4,500"},{"From": "Tirupati",    "To": "Chennai",    "Airlines": "Indian Airlines",    "Seats": 27,    "FlightNo": "IND010",    "Date": "23/08/2019",    "Ref_no": "123476365",    "Connection": "False",    "Price": "Rs 4,000"},{  "From": "Tirupati",    "To": "Chennai",    "Airlines": "John Airlines",    "Seats": 27,    "FlightNo": "INDJ10",    "Date": "23/08/2019",    "Ref_no": "123476360565,432423,4326754,421214,5757567",    "Connection": "True",    "Price": "Rs 1,860"},{"From": "Bengaluru","To": "Tirupati","Airlines": "Balaji Airlines","Seats": 29,"FlightNo": "BA1030","Date": "24/08/2019","Ref_no": "12323233245,8686867,86867867,24235345","Connection": "True","Price": "Rs 2,000"},{    "From": "Bengaluru",    "To": "Tirupati",    "Airlines": "Bengaluru Airlines",    "Seats": 29,    "FlightNo": "BAN1030",    "Date": "24/08/2019",    "Ref_no": "1289245,862342,97897,4242867,786868,98243",    "Connection": "False",    "Price": "Rs 3,000"},{    "From": "Bengaluru",    "To": "Tirupati",    "Airlines": "Spicejet Airlines",    "Seats": 29,    "FlightNo": "SPJ1030",    "Date": "24/08/2019",    "Ref_no": "128956245",    "Connection": "False",    "Price": "Rs 3,500"},{    "From": "Bengaluru",    "To": "Tirupati",    "Airlines": "Indigo Airlines",    "Seats": 29,    "FlightNo": "INGA1030",    "Date": "24/08/2019",    "Ref_no": "18928956245",    "Connection": "True",    "Price": "Rs 2,100"},{"From": "Delhi","To": "Chennai","Airlines": "Air Asia","Seats": 30,"FlightNo": "IA010","Date": "25/08/2019","Ref_no": "1236","Connection": "True","Price": "Rs 2,500"},{    "From": "Delhi",    "To": "Chennai",    "Airlines": "Air Indian",    "Seats": 30,    "FlightNo": "IAN010",    "Date": "25/08/2019",    "Ref_no": "123640",    "Connection": "False",    "Price": "Rs 5,000"},{    "From": "Delhi",    "To": "Chennai",    "Airlines": "Chennai Airlines",    "Seats": 30,    "FlightNo": "CHN010",    "Date": "25/08/2019",    "Ref_no": "123678640",    "Connection": "False",    "Price": "Rs 6,000"},{    "From": "Delhi",    "To": "Chennai",    "Airlines": "Delhi Airlines",    "Seats": 30,    "FlightNo": "DL010",    "Date": "25/08/2019",    "Ref_no": "1785640",    "Connection": "True",    "Price": "Rs 3,000"},{"From": "Velha Goa","To": "Bengaluru","Airlines": "Air India","Seats": 31,"FlightNo": "AIR02","Date": "26/08/2019","Ref_no": "1237","Connection": "False","Price": "Rs 6,000"},{    "From": "Velha Goa",    "To": "Bengaluru",    "Airlines": "Bharth Airlines",    "Seats": 31,    "FlightNo": "ABA0232",    "Date": "26/08/2019",    "Ref_no": "109237",    "Connection": "False",    "Price": "Rs 6,000"},{    "From": "Velha Goa",    "To": "Bengaluru",    "Airlines": "Spicejet Airlines",    "Seats": 31,    "FlightNo": "SPJ02132",    "Date": "26/08/2019",    "Ref_no": "1019237",    "Connection": "True",    "Price": "Rs 3,000"},{    "From": "Velha Goa",    "To": "Bengaluru",    "Airlines": "Velha Goa Airlines",    "Seats": 31,    "FlightNo": "Velha Goa02132",    "Date": "26/08/2019",    "Ref_no": "19237",    "Connection": "True",    "Price": "Rs 2,750"},{"From": "Kochi","To": "Bengaluru",    "Connection": "False","Airlines": "Indigo","Seats": 38,"FlightNo": "I213","Price": "Rs 21,750","Date": "27/08/2019","Ref_no": "1238"},{"From": "Mumbai","To": "Velha Goa","Airlines": "Spicejet",    "Connection": "False","Seats": 39,"FlightNo": "SP10","Price": "Rs 2,750","Date": "28/08/2019","Ref_no": "1239"},{"From": "Pune","To": "Delhi","Airlines": "Spicejet",    "Connection": "False","Seats": 50,"FlightNo": "SP20","Date": "29/08/2019","Ref_no": "1240","Price": "Rs 12,750"},{"From": "Kochi","To": "Pune","Airlines": "Air India","Seats": 52,"FlightNo": "AI23",    "Connection": "False","Date": "30/08/2019","Ref_no": "1241","Price": "Rs 5,750"},{"From": "Madurai","To": "Tirupati","Airlines": "Balaji Airlines","Seats": 58,"FlightNo": "BA3457","Date": "01/09/2019",    "Connection": "False","Ref_no": "1242","Price": "Rs 1,750"} ] }';
 
  function welcome(agent) {
    agent.add(`Hi, I'm your flight booking assistant. I can help you with flight booking`);
    agent.add(`Please Let me know where you want to fly!`);
  }
 
  function fallback(agent) {
    agent.add(`Sorry, my knowledge is limited only to Flight Booking and Cancellation`);
  }
  
  function Destination(agent){
    const destination_city = agent.parameters.city;
    agent.context.set({'name':'userdestination','lifespan': 10,'parameters':{'city':agent.parameters.city}});
    agent.add("Okay,Where you are flying from?"); 
  }
  
  function Source(agent){
        const source_city = agent.parameters.source;
        agent.context.set({'name':'usersource','lifespan': 10,'parameters':{'source':agent.parameters.source}});
        agent.add("Now please tell me date on the day you want to travel."); 
  }
  
  function userDate(agent){
    let user_travel_date = agent.parameters.date;
    agent.context.set({'name':'date','lifespan': 10,'parameters':{'date':agent.parameters.date}});
    user_travel_date = user_travel_date.substring(8,10)+"/"+user_travel_date.substring(5,7)+"/"+user_travel_date.substring(0,4);
    var destination_city=agent.context.get('userdestination').parameters.city;
    var source_city=agent.context.get('usersource').parameters.source;
    var k =0;    var obj = JSON.parse(totalflights);
    var data="From : "+source_city+",\nTo : "+destination_city; var sp=[];   var flight_no = [];
    for(var i=0;i<flight_json.length;i++){
      var src = obj.inst[i].From;
      var dec = obj.inst[i].To;
      var date1 = obj.inst[i].Date;
      var FlightNo = obj.inst[i].FlightNo;
   
    if((src.toLowerCase() == source_city.toLowerCase()) && (dec.toLowerCase() == destination_city.toLowerCase()) && (date1 == user_travel_date)  ){
        data += "\n\nDate : "+date1+",\nFlightNo : "+ FlightNo + "\nprice : "+obj.inst[i].Price+"\n--------\n" ; 
        flight_no.push(FlightNo);
      }
    }
      
    if(data.length > 1){
        agent.add(data);
        agent.context.set({'name':'data','lifespan': 10,'parameters':{'data':data}});
        agent.add("please select the flight number for futher proceedings");
        for(var len=0;len<flight_no.length;len++){
            agent.add(new Suggestion(flight_no[len]));
        }
    }
    else{
        agent.add("No flight found with requested information.");
    }
  }

  
  
  function select_flight(agent){
      var selected_flight = agent.parameters.fltno;
      agent.context.set({'name':'selected_flight','lifespan': 10,'parameters':{'fltno':agent.parameters.fltno}});
      agent.add("Okay. To proceed futher for booking please let me know your name.");
  }
  
  
  function username(agent){
      var name = agent.parameters.name;
      var phone = agent.parameters.phone;
                
                if(phone.length == 10){
                    agent.context.set({'name':'userphone','lifespan': 10,'parameters':{'phone':agent.parameters.phone}});
                    agent.context.set({'name':'username','lifespan': 10,'parameters':{'name':agent.parameters.name}});
                    agent.add("Now please let us know your 6 digit ID");
                }
          else{
              agent.add("I want to know your 10 digit Mobile number");
          }

  }
  
  function id(agent){
      var number = agent.parameters.number;
      var destination_city=agent.context.get('userdestination').parameters.city;
      var source_city=agent.context.get('usersource').parameters.source;
      var travel_date=agent.context.get('date').parameters.date;
      travel_date = travel_date.substring(8,10)+"/"+travel_date.substring(5,7)+"/"+travel_date.substring(0,4);
      var selected_flight=agent.context.get('selected_flight').parameters.fltno;
      var name=agent.context.get('username').parameters.name;
      var phone=agent.context.get('userphone').parameters.phone;
      agent.add("Hello "+name+", the following are the flight details.");
      agent.add("Flight No :  "+selected_flight+" \nDestination : "+destination_city+" \nSource : "+source_city+" \nDate: "+travel_date+".\nYour ticket has been booked on ref number YM45FH. You will get a message shortly to "+ phone+". Thanks for booking with us.");
  }
  
  function direct_flights(agent){
      var destination_city=agent.context.get('userdestination').parameters.city;
      var source_city=agent.context.get('usersource').parameters.source;
      var travel_date=agent.context.get('date').parameters.date;
      travel_date = travel_date.substring(8,10)+"/"+travel_date.substring(5,7)+"/"+travel_date.substring(0,4);
      var obj = JSON.parse(totalflights);
      var data="From : "+source_city+",\nTo : "+destination_city;
      var sp=[]; var flight_no = [];
      for(var i=0;i<flight_json.length;i++){
          var src = obj.inst[i].From;
          var dec = obj.inst[i].To;
          var date1 = obj.inst[i].Date;
          var FlightNo = obj.inst[i].FlightNo; 
    if((src.toLowerCase() == source_city.toLowerCase()) && (dec.toLowerCase() == destination_city.toLowerCase()) && (date1 == travel_date) && (obj.inst[i].Connection == "True")  ){
        data += "\nDate : "+date1+",\nFlightNo : "+ FlightNo + "\nprice : "+obj.inst[i].Price+"\n--------\n" ; 
        flight_no.push(FlightNo);
        
      }
    }
    if(data.length > 1){
        agent.add(data);
        agent.add("Now Select the flight number to to book the flight.");
        for(var len=0;len<flight_no.length;len++){
            agent.add(new Suggestion(flight_no[len]));
        }
    }
    else{
        var All_Flight_data=agent.context.get('data').parameters.data;
        agent.add("We can not find any direct flight to your destination city. We are showing connected flights to you. Please select the flight number to proceed further");
        agent.add(All_Flight_data);
    }
  }
  
  function low_to_high(agent){
      var destination_city=agent.context.get('userdestination').parameters.city;
      var source_city=agent.context.get('usersource').parameters.source;
      var travel_date=agent.context.get('date').parameters.date;
      travel_date = travel_date.substring(8,10)+"/"+travel_date.substring(5,7)+"/"+travel_date.substring(0,4);
      var obj = JSON.parse(totalflights);
      var data="From : "+source_city+",\nTo : "+destination_city;
      var flight_no = []; var price=[];
      
      for(var i=0;i<flight_json.length;i++){
          var src = obj.inst[i].From;
          var dec = obj.inst[i].To;
          var date1 = obj.inst[i].Date;
          var FlightNo = obj.inst[i].FlightNo; 
          var pri = obj.inst[i].Price; 
    if((src.toLowerCase() == source_city.toLowerCase()) && (dec.toLowerCase() == destination_city.toLowerCase()) && (date1 == travel_date)){
        flight_no.push(FlightNo);
        price.push(pri);
      }
    }
    var sorted_price =price;
    sorted_price =sorted_price.sort();
        console.log("sorted price--->"+sorted_price);

    var sorted_flights =[];
    
    for( let j=0;j<sorted_price.length;j++){
        for( let k=0;k<sorted_price.length;k++){
            if(sorted_price[j]==price[k]){
                        sorted_flights.push(flight_no[k]);
                            console.log("sorted_flights--->"+sorted_flights);

            }
        }
    }
    
          for(var ij=0;ij<sorted_flights.length;ij++){
              data += "\nDate : "+travel_date+",\nFlightNo : "+ sorted_flights[ij] + "\nprice : "+sorted_price[ij]+"\n--------\n" ;
    }
        agent.add(data);
        agent.add("Please do select the flight number to proceed further.");
  }



  var flight_json =
    [{
"From": "Chennai",
"To": "Singapore",
"Airlines": "Singapore Airlines",
"Seats": 25,
"FlightNo": "SA1234",
"Date":"22/08/2019",
"Ref_no": "1290,432,454545,667567,32312",
"Connection": "False",
"Price": "Rs 22,000"
},
{
    "From": "Chennai",
    "To": "Singapore",
    "Airlines": "China Airlines",
    "Seats": 25,
    "FlightNo": "CA1434",
    "Date":"22/08/2019",
    "Ref_no": "129032,43247,84432,235674,976543",
    "Connection": "False",
    "Price": "Rs 19,000"
},
{
    "From": "Chennai",
    "To": "Singapore",
    "Airlines": "ABC Airlines",
    "Seats": 25,
    "FlightNo": "AA234",
    "Date":"22/08/2019",
    "Ref_no": "129023,45643,23423412,65757",
    "Connection": "True",
    "Price": "Rs 13,000"
},
{
    "From": "Chennai",
    "To": "Singapore",
    "Airlines": "XYZ Airlines",
    "Seats": 25,
    "FlightNo": "YZ1234",
    "Date":"22/08/2019",
    "Ref_no": "1290231,53523,4324656,78867,2426475,78675",
    "Connection": "True",
    "Price": "Rs 12,000"
},
{
"From": "Tirupati",
"To": "Chennai",
"Airlines": "Balaji Airlines",
"Seats": 27,
"FlightNo": "BA010",
"Date": "23/08/2019",
"Ref_no": "1234",
"Connection": "True",
"Price": "Rs 2,000"
},
{
    "From": "Tirupati",
    "To": "Chennai",
    "Airlines": "iOPEX Airlines",
    "Seats": 27,
    "FlightNo": "iOPEX010",
    "Date": "23/08/2019",
    "Ref_no": "12347665,24424,6876,864234,64242644,424646,75673563,8698657,2424,23423,442",
    "Connection": "False",
    "Price": "Rs 4,500"
},
{
    "From": "Tirupati",
    "To": "Chennai",
    "Airlines": "Indian Airlines",
    "Seats": 27,
    "FlightNo": "IND010",
    "Date": "23/08/2019",
    "Ref_no": "123476365",
    "Connection": "False",
    "Price": "Rs 4,000"
},
{
    "From": "Tirupati",
    "To": "Chennai",
    "Airlines": "John Airlines",
    "Seats": 27,
    "FlightNo": "INDJ10",
    "Date": "23/08/2019",
    "Ref_no": "123476360565,432423,4326754,421214,5757567",
    "Connection": "True",
    "Price": "Rs 1,860"
},
{
"From": "Bengaluru",
"To": "Tirupati",
"Airlines": "Balaji Airlines",
"Seats": 29,
"FlightNo": "BA1030",
"Date": "24/08/2019",
"Ref_no": "12323233245,8686867,86867867,24235345",
"Connection": "True",
"Price": "Rs 2,000"
},
{
    "From": "Bengaluru",
    "To": "Tirupati",
    "Airlines": "Bengaluru Airlines",
    "Seats": 29,
    "FlightNo": "BAN1030",
    "Date": "24/08/2019",
    "Ref_no": "1289245,862342,97897,4242867,786868,98243",
    "Connection": "False",
    "Price": "Rs 3,000"
},
{
    "From": "Bengaluru",
    "To": "Tirupati",
    "Airlines": "Spicejet Airlines",
    "Seats": 29,
    "FlightNo": "SPJ1030",
    "Date": "24/08/2019",
    "Ref_no": "128956245",
    "Connection": "False",
    "Price": "Rs 3,500"
},
{
    "From": "Bengaluru",
    "To": "Tirupati",
    "Airlines": "Indigo Airlines",
    "Seats": 29,
    "FlightNo": "INGA1030",
    "Date": "24/08/2019",
    "Ref_no": "18928956245",
    "Connection": "True",
    "Price": "Rs 2,100"
},
{
"From": "Delhi",
"To": "Chennai",
"Airlines": "Air Asia",
"Seats": 30,
"FlightNo": "IA010",
"Date": "25/08/2019",
"Ref_no": "1236",
"Connection": "True",
"Price": "Rs 2,500"
},
{
    "From": "Delhi",
    "To": "Chennai",
    "Airlines": "Air Indian",
    "Seats": 30,
    "FlightNo": "IAN010",
    "Date": "25/08/2019",
    "Ref_no": "123640",
    "Connection": "False",
    "Price": "Rs 5,000"
},
{
    "From": "Delhi",
    "To": "Chennai",
    "Airlines": "Chennai Airlines",
    "Seats": 30,
    "FlightNo": "CHN010",
    "Date": "25/08/2019",
    "Ref_no": "123678640",
    "Connection": "False",
    "Price": "Rs 6,000"
},
{
    "From": "Delhi",
    "To": "Chennai",
    "Airlines": "Delhi Airlines",
    "Seats": 30,
    "FlightNo": "DL010",
    "Date": "25/08/2019",
    "Ref_no": "1785640",
    "Connection": "True",
    "Price": "Rs 3,000"
},
{
"From": "Velha Goa",
"To": "Bengaluru",
"Airlines": "Air India",
"Seats": 31,
"FlightNo": "AIR02",
"Date": "26/08/2019",
"Ref_no": "1237",
"Connection": "False",
"Price": "Rs 6,000"
},
{
    "From": "Velha Goa",
    "To": "Bengaluru",
    "Airlines": "Bharth Airlines",
    "Seats": 31,
    "FlightNo": "ABA0232",
    "Date": "26/08/2019",
    "Ref_no": "109237",
    "Connection": "False",
    "Price": "Rs 6,000"
},
{
    "From": "Velha Goa",
    "To": "Bengaluru",
    "Airlines": "Spicejet Airlines",
    "Seats": 31,
    "FlightNo": "SPJ02132",
    "Date": "26/08/2019",
    "Ref_no": "1019237",
    "Connection": "True",
    "Price": "Rs 3,000"
},
{
    "From": "Velha Goa",
    "To": "Bengaluru",
    "Airlines": "Velha Goa Airlines",
    "Seats": 31,
    "FlightNo": "Velha Goa02132",
    "Date": "26/08/2019",
    "Ref_no": "19237",
    "Connection": "True",
    "Price": "Rs 2,750"
},
{
"From": "Kochi",
"To": "Bengaluru",
"Airlines": "Indigo",
"Seats": 38,
"FlightNo": "I213",
"Date": "27/08/2019",
"Ref_no": "1238"
},
{
"From": "Mumbai",
"To": "Velha Goa",
"Airlines": "Spicejet",
"Seats": 39,
"FlightNo": "SP10",
"Date": "28/08/2019",
"Ref_no": "1239"
},
{
"From": "Pune",
"To": "Delhi",
"Airlines": "Spicejet",
"Seats": 50,
"FlightNo": "SP20",
"Date": "29/08/2019",
"Ref_no": "1240"
},
{
"From": "Kochi",
"To": "Pune",
"Airlines": "Air India",
"Seats": 52,
"FlightNo": "AI23",
"Date": "30/08/2019",
"Ref_no": "1241"
},
{
"From": "Madurai",
"To": "Tirupati",
"Airlines": "Balaji Airlines",
"Seats": 58,
"FlightNo": "BA3457",
"Date": "01/09/2019",
"Ref_no": "1242"
}
];
  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);
  intentMap.set('user Destination', Destination);
  intentMap.set('Source', Source);
  intentMap.set('get user Date', userDate);
  intentMap.set('select flight', select_flight);
  intentMap.set('user name',username);
  intentMap.set('user id',id);
  intentMap.set('get direct flights',direct_flights);
  intentMap.set('low_to_high',low_to_high);


  agent.handleRequest(intentMap);
});